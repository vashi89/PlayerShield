-- PlayerShield: arco segmentado de escudo del jugador (WoW 3.3.5)
-- Autor: Vash
local ADDON, PS = ...
local env = PS.env
local L = PS.L

local floor, ceil, sin, cos, rad = math.floor, math.ceil, math.sin, math.cos, math.rad
local TEXTURE = "Interface\\AddOns\\" .. ADDON .. "\\segment"
local MAX_SEGMENTS = 100

local defaults = {
	curve = 35,        -- grados totales del arco (1-360)
	rotation = 0,      -- rotacion del arco (-180 a 180)
	segments = 22,     -- cantidad de segmentos (3-100)
	direction = 1,     -- 1 = antihorario, 2 = horario
	size = 25,         -- tamano de cada segmento (px)
	font = "MSBT Porky",  -- fuente del texto
	fontSize = 18,     -- tamano del texto
	x = 130,  -- posicion respecto al centro de la pantalla
	y = 0,
	textX = -10,       -- posicion del texto respecto al arco
	textY = -100,
}
local DB

-- Colores por tipo de dano (los mismos de la aura original)
local SCHOOL_COLORS = {
	All      = {0.949, 0.890, 0.561},
	Magic    = {0.000, 0.502, 1.000},
	Physical = {0.992, 0.792, 0.635},
	Arcane   = {1.000, 0.612, 1.000},
	Fire     = {1.000, 0.502, 0.000},
	Frost    = {0.000, 1.000, 1.000},
	Holy     = {1.000, 1.000, 0.000},
	Nature   = {0.502, 1.000, 0.000},
	Shadow   = {0.729, 0.459, 1.000},
	DivineAegis = {1.000, 0.820, 0.000},  -- amarillo intenso (solo Divine Aegis)
}
local SCHOOLS = {"All", "Physical", "Magic", "Holy", "Fire", "Nature", "Frost", "Shadow", "Arcane"}
env.schools = SCHOOLS

-- Fuentes ----------------------------------------------------------------
local BUILTIN_FONTS = {
	["Friz Quadrata"] = "Fonts\\FRIZQT__.TTF",
	["Arial Narrow"]  = "Fonts\\ARIALN.TTF",
	["Skurri"]        = "Fonts\\skurri.ttf",
	["Morpheus"]      = "Fonts\\MORPHEUS.TTF",
}
local function GetLSM()
	return LibStub and LibStub("LibSharedMedia-3.0", true)
end
local function FontList()
	local list, seen = {}, {}
	for name in pairs(BUILTIN_FONTS) do list[#list + 1] = name; seen[name] = true end
	local LSM = GetLSM()
	if LSM then
		for _, name in ipairs(LSM:List("font")) do
			if not seen[name] then list[#list + 1] = name; seen[name] = true end
		end
	end
	table.sort(list)
	return list
end
local function FontPath(name)
	local LSM = GetLSM()
	local path = LSM and LSM:Fetch("font", name, true)
	return path or BUILTIN_FONTS[name] or STANDARD_TEXT_FONT
end

-- Frames -----------------------------------------------------------------
local container = CreateFrame("Frame", "PlayerShieldFrame", UIParent)
container:SetSize(40, 40)
container:SetFrameStrata("LOW")
container:SetMovable(true)
container:SetClampedToScreen(true)

local mover = container:CreateTexture(nil, "BACKGROUND")
mover:SetAllPoints(container)
mover:SetTexture(0, 1, 0, 0.35)
mover:Hide()

local label = container:CreateFontString(nil, "OVERLAY")
local seg = {}   -- texturas de los segmentos

local function SetRotation(tex, deg)
	-- rotacion antihoraria de la imagen mediante coordenadas de textura
	local a = rad(deg)
	local c, s = cos(a), sin(a)
	local function pt(px, py)
		local qx = px * c + py * s
		local qy = -px * s + py * c
		return 0.5 + qx, 0.5 - qy
	end
	local ulx, uly = pt(-0.5, 0.5)
	local llx, lly = pt(-0.5, -0.5)
	local urx, ury = pt(0.5, 0.5)
	local lrx, lry = pt(0.5, -0.5)
	tex:SetTexCoord(ulx, uly, llx, lly, urx, ury, lrx, lry)
end

local function GetSegment(i)
	local t = seg[i]
	if not t then
		t = container:CreateTexture(nil, "ARTWORK")
		t:SetTexture(TEXTURE)
		t:SetBlendMode("ADD")
		t:Hide()
		seg[i] = t
	end
	return t
end

-- Estado visual ------------------------------------------------------------
local shown = 0          -- segmentos mostrados ahora mismo
local target = 0         -- segmentos que deberian verse
local segmentSchool = {} -- tipo de dano por segmento
local lastTick = 0
local anim = CreateFrame("Frame")
anim:Hide()

local function PaintSegment(i)
	local t = seg[i]
	local col = SCHOOL_COLORS[segmentSchool[i] or "All"] or SCHOOL_COLORS.All
	t:SetVertexColor(col[1], col[2], col[3], 1)
end

local function ApplyShown()
	for i = 1, DB.segments do
		local t = GetSegment(i)
		if i <= shown then PaintSegment(i); t:Show() else t:Hide() end
	end
	for i = DB.segments + 1, #seg do seg[i]:Hide() end
end

anim:SetScript("OnUpdate", function(self, elapsed)
	lastTick = lastTick + elapsed
	local step = 0.25 / DB.segments
	if lastTick < step then return end
	lastTick = 0
	if shown < target then
		shown = shown + 1
	elseif shown > target then
		shown = shown - 1
	end
	ApplyShown()
	-- mantener los colores al dia mientras hay segmentos visibles
	if shown == target then self:Hide() end
end)

local function Layout()
	local N, S = DB.segments, DB.size
	local pitch = S * 18 / 64
	local da = DB.curve / (N - 1)
	local R = 0.5 * pitch / sin(rad(da / 2))
	local ro = DB.rotation
	local d = (DB.direction == 1) and 1 or -1
	-- Con rotacion mayor a 90 (o menor a -90) el arco se dibuja en espejo
	-- horizontal (lado izquierdo, ")" -> "("), manteniendo segmentos al derecho.
	local mirror = (ro > 90 or ro < -90)
	if mirror then
		ro = 180 - ro
		if ro > 180 then ro = ro - 360 elseif ro < -180 then ro = ro + 360 end
	end
	local cro, sro = cos(rad(ro)), sin(rad(ro))
	for i = 1, N do
		local a = ro + d * da * (i - (N + 1) / 2)
		local t = GetSegment(i)
		t:SetSize(S, S)
		t:ClearAllPoints()
		if mirror then
			t:SetPoint("CENTER", container, "CENTER", -R * (cos(rad(a)) - cro), R * (sin(rad(a)) - sro))
			SetRotation(t, -a)
		else
			t:SetPoint("CENTER", container, "CENTER", R * (cos(rad(a)) - cro), R * (sin(rad(a)) - sro))
			SetRotation(t, a)
		end
	end
	for i = N + 1, #seg do seg[i]:Hide() end
	if shown > N then shown = N end
	if target > N then target = N end
	ApplyShown()
end

local function ApplyFont()
	local ok = label:SetFont(FontPath(DB.font), DB.fontSize, "OUTLINE")
	if not ok then label:SetFont(STANDARD_TEXT_FONT, DB.fontSize, "OUTLINE") end
end

local function ApplyPosition()
	container:ClearAllPoints()
	container:SetPoint("CENTER", UIParent, "CENTER", DB.x, DB.y)
	label:ClearAllPoints()
	label:SetPoint("BOTTOM", container, "CENTER", DB.textX, DB.textY)
end

function PS:ApplyAll()
	ApplyPosition()
	ApplyFont()
	Layout()
end

-- Divine Aegis -------------------------------------------------------------
local DIVINE_AEGIS = 47753
local baseline = 0        -- absorcion que cuenta como 100% de la barra
local rebase = false      -- true mientras se activa un escudo (no Divine Aegis)
local inPreview = false

-- true (y su valor) si Divine Aegis es el unico escudo con absorcion
local function SoloDivineAegis()
	local da = env.currentAbsorb[DIVINE_AEGIS]
	if not da or da <= 0 then return false end
	for spell in pairs(env.maxAbsorb) do
		if spell ~= DIVINE_AEGIS and (env.currentAbsorb[spell] or 0) > 0 then
			return false
		end
	end
	return true, da
end

-- al activar cualquier escudo que no sea Divine Aegis, la barra vuelve a salir llena
local origApplyAura = env.ApplyAura
function env:ApplyAura(spellId, amount)
	if spellId ~= DIVINE_AEGIS and self.absorbDb[spellId] then rebase = true end
	-- Divine Aegis sobre otro escudo activo: la barra llena pasa a ser escudo + Divine Aegis,
	-- asi al irse Divine Aegis la barra baja cuadritos
	if spellId == DIVINE_AEGIS and self.absorbDb[spellId] then
		for spell in pairs(self.maxAbsorb) do
			if spell ~= DIVINE_AEGIS and (self.currentAbsorb[spell] or 0) > 0 then rebase = true break end
		end
	end
	local r = origApplyAura(self, spellId, amount)
	rebase = false
	return r
end

-- al irse Divine Aegis (absorbido, disipado o expirado) la barra se ajusta al instante
local instantDrop = false
local origRemoveAura = env.RemoveAura
function env:RemoveAura(spellId)
	if spellId == DIVINE_AEGIS and self.currentAbsorb[spellId] then instantDrop = true end
	local r = origRemoveAura(self, spellId)
	instantDrop = false
	return r
end

-- Callback de la logica de absorciones -------------------------------------
-- total, all, physical, magic, holy, fire, nature, frost, shadow, arcane
function PS:OnShieldChanged(total, ...)
	if not DB then return end
	-- texto: valor del escudo mas bajo (igual que la aura original)
	local minValue, totalAbsorb, minIdx = env:LowestAbsorb(total, ...)
	if minValue > 0 then
		local school = SCHOOLS[minIdx]
		local col = SCHOOL_COLORS[school] or SCHOOL_COLORS.All
		label:SetTextColor(col[1], col[2], col[3], 1)
		label:SetText(floor(minValue))
		label:Show()
	else
		label:SetText("")
		label:Hide()
	end

	-- segmentos: cuantos se ven y de que color
	local N = DB.segments
	local currentAbsorb = 0
	for i = 1, select("#", ...) do currentAbsorb = currentAbsorb + select(i, ...) end

	target = 0
	local solo, daValue = SoloDivineAegis()
	if solo and not inPreview then
		-- Solo Divine Aegis: pocas barritas segun su absorcion respecto a la vida maxima
		local hp = UnitHealthMax("player")
		if not hp or hp <= 0 then hp = 1 end
		target = ceil(daValue / hp * N)
		if target < 1 then target = 1 end
		if target > N then target = N end
		for k = 1, N do segmentSchool[k] = "DivineAegis" end
	else
		-- Con escudo: la referencia (100%) se fija al activar el escudo, asi siempre sale lleno
		if currentAbsorb <= 0 then
			baseline = 0
		elseif rebase or baseline <= 0 then
			baseline = currentAbsorb
		end
		local ref = baseline
		if currentAbsorb > 0 and ref > 0 then
			local acc, prevSegment = 0, 0
			for i = 1, select("#", ...) do
				local value = select(i, ...)
				acc = acc + value
				local s = ceil(acc / ref * N)
				if s > N then s = N end
				if value > 0 then
					for k = prevSegment + 1, s do segmentSchool[k] = SCHOOLS[i] end
					prevSegment = s
				end
			end
			target = ceil(currentAbsorb / ref * N)
			if target > N then target = N end
		end
	end
	if instantDrop and shown > target then shown = target end
	ApplyShown()
	lastTick = 0
	anim:Show()
end

-- LowestAbsorb de la aura original devuelve (minValue, total, idx) con el piso aplicado
function env:LowestAbsorb(totalAbsorb, all, physical, magic, ...)
	local minValue, minIdx, value
	for i = 1, select("#", ...) do
		value = select(i, ...)
		if value > 0 and value <= (minValue or value) then
			minIdx = i + 3
			minValue = value
		end
	end
	if minIdx then
		minValue = minValue + magic
	elseif magic > 0 then
		minValue = magic
		minIdx = 3
	end
	if physical > 0 and physical <= (minValue or physical) then
		minValue = physical
		minIdx = 2
	end
	if minIdx then
		minValue = minValue + all
	else
		minValue = all
		minIdx = 1
	end
	return floor(minValue), floor(totalAbsorb), minIdx
end

-- Vista previa -------------------------------------------------------------
local previewing = false
function PS:SetPreview(on)
	previewing = on and true or false
	if previewing then
		-- total, all, physical, magic, holy, fire, nature, frost, shadow, arcane
		local savedBase = baseline
		inPreview = true
		self:OnShieldChanged(10000, 3000, 0, 2000, 0, 2500, 0, 1500, 0, 1000)
		inPreview = false
		baseline = savedBase
	else
		env:UpdateValues()
	end
end
function PS:IsPreviewing() return previewing end

-- Mover ----------------------------------------------------------------------
local function SaveDragPosition()
	local cx, cy = container:GetCenter()
	local ux, uy = UIParent:GetCenter()
	DB.x, DB.y = cx - ux, cy - uy
	ApplyPosition()
end
container:SetScript("OnDragStart", function(self) self:StartMoving() end)
container:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); SaveDragPosition() end)

function PS:SetUnlocked(on)
	if on then
		container:EnableMouse(true)
		container:RegisterForDrag("LeftButton")
		mover:Show()
		print("|cff33ff99PlayerShield|r: " .. L.unlock_msg)
	else
		container:EnableMouse(false)
		container:RegisterForDrag()
		mover:Hide()
	end
	self.unlocked = on and true or false
end

-- Eventos --------------------------------------------------------------------
local ev = CreateFrame("Frame")
local delay, pendingEnter = 0, false
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
ev:RegisterEvent("GLYPH_ADDED")
ev:RegisterEvent("GLYPH_REMOVED")
ev:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
ev:RegisterEvent("PLAYER_TALENT_UPDATE")
ev:RegisterEvent("CHAT_MSG_ADDON")

ev:SetScript("OnEvent", function(self, event, ...)
	if event == "COMBAT_LOG_EVENT_UNFILTERED" then
		-- timestamp, subEvent, sourceGUID, sourceName, sourceFlags, destGUID, ...
		local _, _, sourceGUID, _, _, destGUID = ...
		local me = env.playerGUID
		if destGUID ~= me and sourceGUID ~= me then return end
		env:OnEvent(event, ...)
	elseif event == "ADDON_LOADED" then
		if (...) ~= ADDON then return end
		PlayerShieldDB = PlayerShieldDB or {}
		DB = PlayerShieldDB
		for k, v in pairs(defaults) do
			if DB[k] == nil then DB[k] = v end
		end
		if not GetLSM() or not GetLSM():Fetch("font", DB.font, true) then
			if not BUILTIN_FONTS[DB.font] then DB.font = "Friz Quadrata" end
		end
		PS.DB = DB
		PS:ApplyAll()
		self:UnregisterEvent("ADDON_LOADED")
	elseif event == "PLAYER_LOGIN" then
		env.playerGUID = UnitGUID("player")
		env.playerClass = select(2, UnitClass("player"))
		env.playerName = UnitName("player")
	elseif event == "PLAYER_ENTERING_WORLD" then
		env.playerGUID = UnitGUID("player")
		pendingEnter, delay = true, 0   -- la aura original espera un instante (talentos listos)
	elseif event == "CHAT_MSG_ADDON" then
		env:OnEvent(event, ...)
	else
		env:OnEvent(event, ...)
	end
end)

ev:SetScript("OnUpdate", function(self, elapsed)
	if pendingEnter then
		delay = delay + elapsed
		if delay >= 1 then
			pendingEnter = false
			env:OnEvent("WA_DELAYED_PLAYER_ENTERING_WORLD")
		end
	end
end)

-- Panel de opciones ----------------------------------------------------------
local panel = CreateFrame("Frame", "PlayerShieldOptions", UIParent)
panel.name = "PlayerShield"

local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
title:SetPoint("TOPLEFT", 16, -16)
title:SetText("PlayerShield")

local function MakeSlider(name, text, minV, maxV, step, key, x, y)
	local s = CreateFrame("Slider", "PlayerShieldSlider" .. name, panel, "OptionsSliderTemplate")
	s:SetPoint("TOPLEFT", x, y)
	s:SetWidth(200)
	s:SetMinMaxValues(minV, maxV)
	s:SetValueStep(step)
	_G[s:GetName() .. "Low"]:SetText(minV)
	_G[s:GetName() .. "High"]:SetText(maxV)
	s.label = _G[s:GetName() .. "Text"]
	s.key, s.text = key, text
	s:SetScript("OnValueChanged", function(self, value)
		value = floor(value / step + 0.5) * step
		self.label:SetText(self.text .. ": " .. value)
		if DB and DB[self.key] ~= value then
			DB[self.key] = value
			PS:ApplyAll()
		end
	end)
	return s
end

local sCurve    = MakeSlider("Curve",    L.curve, 1, 360, 1, "curve", 20, -70)
local sRotation = MakeSlider("Rotation", L.rotation, -180, 180, 1, "rotation", 260, -70)
local sSegments = MakeSlider("Segments", L.segments, 3, 100, 1, "segments", 20, -130)
local sSize     = MakeSlider("Size",     L.size, 10, 150, 1, "size", 260, -130)

-- Direccion
local dirLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
dirLabel:SetPoint("TOPLEFT", 260, -185)
dirLabel:SetText(L.direction)
local dd = CreateFrame("Frame", "PlayerShieldDirection", panel, "UIDropDownMenuTemplate")
dd:SetPoint("TOPLEFT", 244, -200)
UIDropDownMenu_SetWidth(dd, 150)
local DIRS = {L.ccw, L.cw}
UIDropDownMenu_Initialize(dd, function()
	for i, text in ipairs(DIRS) do
		local info = UIDropDownMenu_CreateInfo()
		info.text = text
		info.checked = (DB and DB.direction == i)
		info.func = function()
			DB.direction = i
			UIDropDownMenu_SetText(dd, DIRS[i])
			PS:ApplyAll()
		end
		UIDropDownMenu_AddButton(info)
	end
end)

-- Texto: fuente (lista desplegable), tamano y posicion --------------------------
local textHeader = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
textHeader:SetPoint("TOPLEFT", 16, -245)
textHeader:SetText(L.text)

local fontLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
fontLabel:SetPoint("TOPLEFT", 20, -277)
fontLabel:SetText(L.font)

local BACKDROP = {
	bgFile = "Interface\\Buttons\\WHITE8X8",
	edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
	tile = false, edgeSize = 12,
	insets = { left = 3, right = 3, top = 3, bottom = 3 },
}

local fontBtn = CreateFrame("Button", "PlayerShieldFontButton", panel)
fontBtn:SetSize(200, 24)
fontBtn:SetPoint("TOPLEFT", 20, -294)
fontBtn:SetBackdrop(BACKDROP)
fontBtn:SetBackdropColor(0.05, 0.05, 0.05, 0.9)
fontBtn:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
fontBtn:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
fontBtn.text = fontBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
fontBtn.text:SetPoint("LEFT", 8, 0)
fontBtn.text:SetPoint("RIGHT", -24, 0)
fontBtn.text:SetJustifyH("LEFT")
fontBtn.arrow = fontBtn:CreateTexture(nil, "OVERLAY")
fontBtn.arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
fontBtn.arrow:SetSize(22, 22)
fontBtn.arrow:SetPoint("RIGHT", -1, 0)

local function SetFontSafe(fs, name, size)
	local ok = fs:SetFont(FontPath(name), size, "")
	if not ok then fs:SetFont(STANDARD_TEXT_FONT, size, "") end
end

local function UpdateFontButton()
	if not DB then return end
	SetFontSafe(fontBtn.text, DB.font, 12)
	fontBtn.text:SetText(DB.font)
end

-- Lista desplegable con scroll; cada fuente se muestra con su propio tipo de letra
local ROWS, ROW_H = 8, 20
local fonts = {}
local fontList = CreateFrame("Frame", "PlayerShieldFontList", UIParent)
fontList:SetFrameStrata("TOOLTIP")
fontList:SetSize(224, ROWS * ROW_H + 10)
fontList:SetBackdrop(BACKDROP)
fontList:SetBackdropColor(0.06, 0.06, 0.06, 0.97)
fontList:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
fontList:EnableMouse(true)
fontList:EnableMouseWheel(true)
fontList:Hide()

local catcher = CreateFrame("Button", nil, UIParent)   -- cierra la lista al hacer clic fuera
catcher:SetAllPoints(UIParent)
catcher:SetFrameStrata("FULLSCREEN")
catcher:Hide()

local scroll = CreateFrame("ScrollFrame", "PlayerShieldFontScroll", fontList, "FauxScrollFrameTemplate")
scroll:SetPoint("TOPLEFT", 5, -5)
scroll:SetPoint("BOTTOMRIGHT", -27, 5)

local rows = {}
local UpdateFontList
local function CloseFontList()
	fontList:Hide()
	catcher:Hide()
end
for i = 1, ROWS do
	local row = CreateFrame("Button", nil, fontList)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", fontList, "TOPLEFT", 6, -5 - (i - 1) * ROW_H)
	row:SetPoint("RIGHT", fontList, "RIGHT", -28, 0)
	row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
	row.check = row:CreateTexture(nil, "OVERLAY")
	row.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
	row.check:SetSize(18, 18)
	row.check:SetPoint("LEFT", 0, 0)
	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	row.text:SetPoint("LEFT", 20, 0)
	row.text:SetPoint("RIGHT", -2, 0)
	row.text:SetJustifyH("LEFT")
	row:SetScript("OnClick", function(self)
		if not self.name or not DB then return end
		DB.font = self.name
		UpdateFontButton()
		PS:ApplyAll()
		CloseFontList()
	end)
	rows[i] = row
end

UpdateFontList = function()
	local offset = FauxScrollFrame_GetOffset(scroll)
	for i = 1, ROWS do
		local row = rows[i]
		local name = fonts[offset + i]
		if name then
			row.name = name
			SetFontSafe(row.text, name, 14)
			row.text:SetText(name)
			if DB and DB.font == name then row.check:Show() else row.check:Hide() end
			row:Show()
		else
			row.name = nil
			row:Hide()
		end
	end
	FauxScrollFrame_Update(scroll, #fonts, ROWS, ROW_H)
end

scroll:SetScript("OnVerticalScroll", function(self, offset)
	FauxScrollFrame_OnVerticalScroll(self, offset, ROW_H, UpdateFontList)
end)
fontList:SetScript("OnMouseWheel", function(self, delta)
	local bar = _G["PlayerShieldFontScrollScrollBar"]
	bar:SetValue(bar:GetValue() - delta * ROW_H * 2)
end)
catcher:SetScript("OnClick", CloseFontList)

local function OpenFontList()
	if not DB then return end
	fonts = FontList()
	local idx = 1
	for i, n in ipairs(fonts) do if n == DB.font then idx = i break end end
	fontList:ClearAllPoints()
	fontList:SetPoint("TOPLEFT", fontBtn, "BOTTOMLEFT", 0, 2)
	fontList:Show()
	catcher:Show()
	UpdateFontList()
	local off = math.min(math.max(idx - floor(ROWS / 2), 0), math.max(#fonts - ROWS, 0))
	_G["PlayerShieldFontScrollScrollBar"]:SetValue(off * ROW_H)
	UpdateFontList()
end
fontBtn:SetScript("OnClick", function()
	if fontList:IsShown() then CloseFontList() else OpenFontList() end
end)

-- Tamano y posicion del texto
local sFontSize = MakeSlider("FontSize", L.fontsize, 8, 60, 1, "fontSize", 260, -300)
local sTextX = MakeSlider("TextX", L.offsetx, -300, 300, 1, "textX", 20, -360)
local sTextY = MakeSlider("TextY", L.offsety, -300, 300, 1, "textY", 260, -360)

-- Botones
local bMove = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
bMove:SetSize(140, 24); bMove:SetText(L.move); bMove:SetPoint("TOPLEFT", 20, -410)
bMove:SetScript("OnClick", function() PS:SetUnlocked(not PS.unlocked) end)
local bTest = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
bTest:SetSize(140, 24); bTest:SetText(L.preview); bTest:SetPoint("TOPLEFT", 170, -410)
bTest:SetScript("OnClick", function() PS:SetPreview(not PS:IsPreviewing()) end)
local bReset = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
bReset:SetSize(140, 24); bReset:SetText(L.reset); bReset:SetPoint("TOPLEFT", 320, -410)
bReset:SetScript("OnClick", function()
	for k, v in pairs(defaults) do DB[k] = v end
	if not FontPath(DB.font) then DB.font = "Friz Quadrata" end
	panel.refresh()
	PS:ApplyAll()
end)

function panel.refresh()
	if not DB then return end
	sCurve:SetValue(DB.curve); sRotation:SetValue(DB.rotation)
	sSegments:SetValue(DB.segments); sSize:SetValue(DB.size); sFontSize:SetValue(DB.fontSize)
	sTextX:SetValue(DB.textX); sTextY:SetValue(DB.textY)
	UIDropDownMenu_SetText(dd, DIRS[DB.direction] or DIRS[1])
	UpdateFontButton()
end
panel:SetScript("OnShow", panel.refresh)
panel:SetScript("OnHide", function() CloseFontList(); if PS:IsPreviewing() then PS:SetPreview(false) end end)
InterfaceOptions_AddCategory(panel)

-- Comandos ---------------------------------------------------------------------
SLASH_PLAYERSHIELD1 = "/pshield"
SLASH_PLAYERSHIELD2 = "/playershield"
SlashCmdList["PLAYERSHIELD"] = function(msg)
	msg = (msg or ""):lower()
	if msg == "move" then
		PS:SetUnlocked(not PS.unlocked)
	elseif msg == "test" then
		PS:SetPreview(not PS:IsPreviewing())
	else
		InterfaceOptionsFrame_OpenToCategory(panel)
		InterfaceOptionsFrame_OpenToCategory(panel)
	end
end
