-- PlayerShield: textos por idioma del cliente (WoW 3.3.5)
-- Si el idioma no esta traducido se usa espanol (base).
local ADDON, PS = ...
local L = {}
PS.L = L

-- Base: espanol (identico a los textos originales del addon)
local base = {
	curve      = "Curva",
	rotation   = "Rotacion",
	segments   = "Segmentos",
	size       = "Tamano",
	direction  = "Direccion",
	ccw        = "Antihorario",
	cw         = "Horario",
	text       = "Texto",
	font       = "Fuente",
	fontsize   = "Tama\195\177o",
	offsetx    = "Desplazamiento X",
	offsety    = "Desplazamiento Y",
	move       = "Mover",
	preview    = "Vista previa",
	reset      = "Restablecer",
	unlock_msg = "arrastra el recuadro verde para mover. /pshield move para bloquear.",
}

local T = {}

T.enUS = {
	curve = "Curve", rotation = "Rotation", segments = "Segments", size = "Size",
	direction = "Direction", ccw = "Counterclockwise", cw = "Clockwise",
	text = "Text", font = "Font", fontsize = "Font size",
	offsetx = "Offset X", offsety = "Offset Y",
	move = "Move", preview = "Preview", reset = "Reset",
	unlock_msg = "drag the green box to move it. /pshield move to lock.",
}

T.deDE = {
	curve = "Kr\195\188mmung", rotation = "Drehung", segments = "Segmente", size = "Gr\195\182\195\159e",
	direction = "Richtung", ccw = "Gegen Uhrzeigersinn", cw = "Im Uhrzeigersinn",
	text = "Text", font = "Schriftart", fontsize = "Schriftgr\195\182\195\159e",
	offsetx = "Versatz X", offsety = "Versatz Y",
	move = "Verschieben", preview = "Vorschau", reset = "Zur\195\188cksetzen",
	unlock_msg = "Ziehe das gr\195\188ne Feld, um es zu verschieben. /pshield move zum Sperren.",
}

T.frFR = {
	curve = "Courbure", rotation = "Rotation", segments = "Segments", size = "Taille",
	direction = "Direction", ccw = "Antihoraire", cw = "Horaire",
	text = "Texte", font = "Police", fontsize = "Taille de la police",
	offsetx = "D\195\169calage X", offsety = "D\195\169calage Y",
	move = "D\195\169placer", preview = "Aper\195\167u", reset = "R\195\169initialiser",
	unlock_msg = "faites glisser le cadre vert pour le d\195\169placer. /pshield move pour verrouiller.",
}

T.ruRU = {
	curve = "Кривизна", rotation = "Поворот", segments = "Сегменты", size = "Размер",
	direction = "Направление", ccw = "Против часовой", cw = "По часовой",
	text = "Текст", font = "Шрифт", fontsize = "Размер шрифта",
	offsetx = "Смещение X", offsety = "Смещение Y",
	move = "Переместить", preview = "Просмотр", reset = "Сбросить",
	unlock_msg = "перетащите зелёную рамку, чтобы переместить. /pshield move — зафиксировать.",
}

T.zhCN = {
	curve = "弧度", rotation = "旋转", segments = "分段", size = "大小",
	direction = "方向", ccw = "逆时针", cw = "顺时针",
	text = "文字", font = "字体", fontsize = "字体大小",
	offsetx = "X 偏移", offsety = "Y 偏移",
	move = "移动", preview = "预览", reset = "重置",
	unlock_msg = "拖动绿色方框来移动。输入 /pshield move 锁定。",
}

T.zhTW = {
	curve = "弧度", rotation = "旋轉", segments = "分段", size = "大小",
	direction = "方向", ccw = "逆時針", cw = "順時針",
	text = "文字", font = "字型", fontsize = "字型大小",
	offsetx = "X 偏移", offsety = "Y 偏移",
	move = "移動", preview = "預覽", reset = "重設",
	unlock_msg = "拖曳綠色方框來移動。輸入 /pshield move 鎖定。",
}

T.koKR = {
	curve = "곡률", rotation = "회전", segments = "분할 수", size = "크기",
	direction = "방향", ccw = "반시계 방향", cw = "시계 방향",
	text = "텍스트", font = "글꼴", fontsize = "글꼴 크기",
	offsetx = "X 오프셋", offsety = "Y 오프셋",
	move = "이동", preview = "미리보기", reset = "초기화",
	unlock_msg = "녹색 상자를 드래그하여 이동하세요. 잠그려면 /pshield move 를 입력하세요.",
}

-- Variantes de cliente que comparten idioma
local ALIAS = { enGB = "enUS", esMX = "esES" }

local loc = GetLocale()
loc = ALIAS[loc] or loc
local t = T[loc]

for k, v in pairs(base) do
	L[k] = (t and t[k]) or v
end
