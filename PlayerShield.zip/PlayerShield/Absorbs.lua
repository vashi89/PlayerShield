-- PlayerShield: seguimiento de escudos/absorciones del jugador (WoW 3.3.5)
-- Autor: Vash
-- Logica portada de la WeakAura "Player Shield".
local ADDON, PS = ...
local aura_env = {}
PS.env = aura_env

aura_env.active = 0
aura_env.spellSchool = {}
aura_env.currentAbsorb = {}
aura_env.maxAbsorb = {}
aura_env.totalAbsorb = 0
aura_env.schoolAbsorb = {0, 0, 0, 0, 0, 0, 0, 0, 0}

aura_env.talentMultiplier = {
    [43039] = 1,
    [48066] = 1,
    [47753] = 0.3,
    [47986] = 1,
    [58597] = 1,
}
aura_env.coeffMultiplier = {
    [48066] = 1,
}
aura_env.mageFrostWarding = false

local critAmout
local restoredNama

function aura_env:CalculateAbsorbValue(spellId, absorbInfo)
    local keys = self.absorbDbKeys
    local bonusHealing = GetSpellBonusHealing()
    local bonusDamage = GetSpellBonusDamage(2)
    if not (self.MageFrostWardSpells[spellId] or self.MageFireWardSpells[spellId]) and bonusHealing < bonusDamage then
        bonusHealing = bonusDamage
    end
    local base = absorbInfo[keys.basePoints]
    local bonusMult = absorbInfo[keys.healingMultiplier]
    local baseMult = self.talentMultiplier[spellId] or 1
    local coeffMult = self.coeffMultiplier[spellId] or 0
    return (base + (bonusHealing * (bonusMult + coeffMult))) * baseMult
end

function aura_env:ApplyAura(spellId, amount)
    local absorbInfo = self.absorbDb[spellId]
    if absorbInfo then
        local value = amount or self:CalculateAbsorbValue(spellId, absorbInfo)
        
        if not self.spellSchool[spellId] then
            self.spellSchool[spellId] = absorbInfo[self.absorbDbKeys.school]
        end
        
        self.active = self.active + 1
        self.currentAbsorb[spellId] = value
        self.maxAbsorb[spellId] = value
        
        self:UpdateValues()
        
        return value
    end
end

function aura_env:RemoveAura(spellId)
    if self.currentAbsorb[spellId] then
        self.currentAbsorb[spellId] = nil
        self.active = self.active - 1
        
        if self.active < 1 then
            self.active = 0
            wipe(self.maxAbsorb)
        end
        
        self:UpdateValues()
    end
end

function aura_env:ApplyDamage(spellId, value)
    local newValue = (self.currentAbsorb[spellId] or 0) - value
    if self.maxAbsorb[spellId] then
        self.currentAbsorb[spellId] = max(0, newValue)
        self:UpdateValues()
    else
        self.currentAbsorb[spellId] = newValue
    end
end

function aura_env:ResetValues()
    wipe(self.currentAbsorb)
    wipe(self.maxAbsorb)
    self:UpdateValues()
end

function aura_env:UpdateValues()
    local values = self.schoolAbsorb
    local keys = self.schoolIdx
    local spellSchool = self.spellSchool
    local current = self.currentAbsorb
    local total = 0
    local key, value, school
    
    for i = 1, #values do
        values[i] = 0
    end
    
    for spell, maxValue in pairs(self.maxAbsorb) do
        school = spellSchool[spell]
        key = keys[school]
        total = total + maxValue
        value = (current[spell] or 0)
        values[key] = values[key] + value
    end
    
    self.totalAbsorb = total
    PS:OnShieldChanged(total, unpack(values))
end

aura_env.AurasList = {}

function aura_env.AbsorbAuraOrderPred(a, b)
    local spellA, spellB = a.spellId, b.spellId
    if spellA == spellB then return a.timestamp < b.timestamp end
    if spellA == 65686 then return true end
    if spellB == 65686 then return false end
    if spellA == 65684 then return true end
    if spellB == 65684 then return false end
    if aura_env.MageFrostWardSpells[spellA] then return true end
    if aura_env.MageFrostWardSpells[spellB] then return false end
    if aura_env.MageFireWardSpells[spellA] then return true end
    if aura_env.MageFireWardSpells[spellB] then return false end
    if aura_env.WarlockShadowWardSpells[spellA] then return true end
    if aura_env.WarlockShadowWardSpells[spellB] then return false end
    if spellA == 58597 then return true end
    if spellB == 58597 then return false end
    if spellA == 28527 then return true end
    if spellB == 28527 then return false end
    if spellA == 47753 then return true end
    if spellB == 47753 then return false end
    if aura_env.MageIceBarrierSpells[spellA] then return true end
    if aura_env.MageIceBarrierSpells[spellB] then return false end
    if aura_env.WarlockSacrificeSpells[spellA] then return true end
    if aura_env.WarlockSacrificeSpells[spellB] then return false end
    return a.timestamp < b.timestamp
end

function aura_env:ParseAbsorb(absorbed, spellSchool)
    local found
    for _, absorbData in ipairs(self.AurasList) do
        if absorbData.spellId == 65686 then
            if bit.band(spellSchool, 0x4) == spellSchool then
                return
            end
        elseif absorbData.spellId == 65684 then
            if bit.band(spellSchool, 0x20) == spellSchool then
                return
            end
        elseif self.MageFrostWardSpells[absorbData.spellId] then
            if bit.band(spellSchool, 0x10) == spellSchool then
                if restoredNama and restoredNama == absorbed then
                    return
                end
                found = absorbData
                break
            end
        elseif self.MageFireWardSpells[absorbData.spellId] then
            if restoredNama and restoredNama == absorbed then
                return
            end
            if bit.band(spellSchool, 0x4) == spellSchool then
                found = absorbData
                break
            end
        elseif self.WarlockShadowWardSpells[absorbData.spellId] then
            if bit.band(spellSchool, 0x20) == spellSchool then
                found = absorbData
                break
            end
        else
            found = absorbData
            break
        end
    end
    if found then
        if found.amount then
            if found.amount > absorbed then
                found.amount = found.amount - absorbed
                self:ApplyDamage(found.spellId, absorbed)
            else
                self:RemoveAura(found.spellId)
                self:ParseAbsorb(absorbed - found.amount, spellSchool)
            end
        else
            self:ApplyDamage(found.spellId, absorbed)
        end
    end
end

function aura_env:ChecMageGlyph()
    local foundGlyph
    for i = 1, GetNumGlyphSockets() do
        local enabled, _, glyphSpell = GetGlyphSocketInfo(i)
        if enabled and glyphSpell == 63095 then
            foundGlyph = true
        end
    end
    self.talentMultiplier[43039] = foundGlyph and 1.3 or 1
end

function aura_env:PRIEST()
    local _, _, _, _, rank = GetTalentInfo(1, 2)
    self.talentMultiplier[48066] = 1 + (rank * 0.01)
    _, _, _, _, rank = GetTalentInfo(1, 9)
    self.talentMultiplier[48066] = self.talentMultiplier[48066] * (1 + rank * 0.05)
    _, _, _, _, rank = GetTalentInfo(1, 16)
    self.talentMultiplier[48066] = self.talentMultiplier[48066] * (1 + rank * 0.02)
    _, _, _, _, rank = GetTalentInfo(2, 19)
    self.talentMultiplier[48066] = self.talentMultiplier[48066] * (1 + rank * 0.01)
    _, _, _, _, rank = GetTalentInfo(1, 27)
    self.coeffMultiplier[48066] = rank > 0 and (rank * 0.08) or 0
end

function aura_env:WARLOCK()
    local _, _, _, _, rank = GetTalentInfo(2, 6)
    self.talentMultiplier[47986] = 1 + (rank * 0.1)
end

function aura_env:PALADIN()
    local _, _, _, _, rank = GetTalentInfo(2, 9)
    self.talentMultiplier[58597] = 1 + (rank * 0.1)
end

function aura_env:MAGE()
    local _, _, _, _, rank = GetTalentInfo(2, 5)
    aura_env.mageFrostWarding = rank > 0
end

function aura_env:CheckTalents()
    if self.playerClass and self[self.playerClass] then
        self[self.playerClass](self)
    end
end

-- Tras /reload o al entrar al mundo: detecta los escudos que ya estan activos
function aura_env:ScanAuras()
    for i = 1, 40 do
        local name, _, _, _, _, _, _, caster, _, _, spellId = UnitBuff("player", i)
        if not name then break end
        if spellId and self.AbsorbSpells[spellId] then
            local mine = caster and (UnitIsUnit(caster, "player") or UnitIsUnit(caster, "pet"))
            local amount
            if mine and self.absorbDb[spellId] then
                amount = self:ApplyAura(spellId)
            end
            table.insert(self.AurasList, {
                timestamp = time() + i / 1000,
                amount = amount,
                sourceGUID = caster and UnitGUID(caster) or nil,
                spellId = spellId,
            })
        end
    end
    table.sort(self.AurasList, self.AbsorbAuraOrderPred)
end

function aura_env:OnEvent(triggerEvent, timestamp, subEvent, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, arg9, ...)
    if triggerEvent == "WA_DELAYED_PLAYER_ENTERING_WORLD" or triggerEvent == "DELAYED_PLAYER_ENTERING_WORLD" or triggerEvent == "COMMENTATOR_ENTER_WORLD" then
        if self.playerClass == "MAGE" then
            self:ChecMageGlyph()
        end
        
        self:CheckTalents()
        -- el estado se reconstruye desde cero (evita duplicados al cambiar de zona)
        self.active = 0
        wipe(self.AurasList)
        self:ResetValues()
        self:ScanAuras()
    elseif self.playerClass == "MAGE" and (triggerEvent == "GLYPH_ADDED" or triggerEvent == "GLYPH_REMOVED") then
        self:ChecMageGlyph()
    elseif triggerEvent == "ACTIVE_TALENT_GROUP_CHANGED" or triggerEvent == "PLAYER_TALENT_UPDATE" then
        self:CheckTalents()
    elseif triggerEvent == "CHAT_MSG_ADDON" and timestamp == "WA_PAD" and subEvent then
        local amount, spellId = string.split(";", subEvent)
        self:ApplyAura(tonumber(spellId), tonumber(amount))
    elseif destGUID == self.playerGUID then
        if subEvent == "SPELL_AURA_APPLIED" or subEvent == "SPELL_AURA_REFRESH" then
            if self.AbsorbSpells[arg9] then
                local amount
                if self.absorbDb[arg9] then
                    if sourceGUID == self.playerGUID or sourceGUID == UnitGUID("pet") then
                        amount = self:ApplyAura(arg9, arg9 == 47753 and critAmout and critAmout * self.talentMultiplier[47753])
                    end
                end
                local found
                if subEvent == "SPELL_AURA_REFRESH" then
                    for _, absorbData in ipairs(self.AurasList) do
                        if absorbData.spellId == arg9 and absorbData.sourceGUID == sourceGUID then
                            absorbData.amount = amount
                            absorbData.timestamp = timestamp
                            found = true
                            break
                        end
                    end
                end
                if not found then
                    local absorbData = {}
                    absorbData.timestamp = timestamp
                    absorbData.amount = amount
                    absorbData.sourceGUID = sourceGUID
                    absorbData.spellId = arg9
                    table.insert(self.AurasList, absorbData)
                end
                table.sort(self.AurasList, self.AbsorbAuraOrderPred)
            end
        elseif subEvent == "SPELL_AURA_REMOVED" then
            if self.AbsorbSpells[arg9] then
                local index
                for i, absorbData in ipairs(self.AurasList) do
                    if absorbData.spellId == arg9 and absorbData.sourceGUID == sourceGUID then
                        index = i
                        break
                    end
                end
                if index then
                    table.remove(self.AurasList, index)
                    table.sort(self.AurasList, self.AbsorbAuraOrderPred)
                    self:RemoveAura(arg9)
                end
            end
        elseif subEvent == "SWING_DAMAGE" then
            local _, _, _, _, absorbed = ...
            if absorbed and absorbed > 0 then
                self:ParseAbsorb(absorbed, 0)
            end
        elseif subEvent == "RANGE_DAMAGE" or subEvent == "SPELL_DAMAGE" or subEvent == "SPELL_PERIODIC_DAMAGE" or subEvent == "DAMAGE_SHIELD" or subEvent == "DAMAGE_SPLIT" then
            local _, spellSchool, _, _, _, _, _, absorbed = ...
            if absorbed and absorbed > 0 then
                self:ParseAbsorb(absorbed, spellSchool)
            end
        elseif subEvent == "ENVIRONMENTAL_DAMAGE" then
            local _, _, _, _, _, absorbed = ...
            if absorbed and absorbed > 0 then
                self:ParseAbsorb(absorbed, 0)
            end
        elseif subEvent == "SWING_MISSED" then
            local amountMissed = ...
            if arg9 == "ABSORB" and amountMissed and amountMissed > 0 then
                self:ParseAbsorb(amountMissed, 0)
            end
        elseif subEvent == "RANGE_MISSED" or subEvent == "SPELL_MISSED" or subEvent == "SPELL_PERIODIC_MISSED" or subEvent == "DAMAGE_SHIELD_MISSED" then
            local _, spellSchool, missType, amountMissed = ...
            if missType == "ABSORB" and amountMissed and amountMissed > 0  then
                self:ParseAbsorb(amountMissed, spellSchool)
            end
        elseif subEvent == "SPELL_HEAL" or subEvent == "SPELL_PERIODIC_HEAL" then
            local _, _, amount, _, _, critical = ...
            critAmout = critical and amount
        elseif self.mageFrostWarding and subEvent == "SPELL_ENERGIZE" then
            local _, _, amount = ...
            restoredNama = amount
        end
    elseif sourceGUID == self.playerGUID and destGUID ~= self.playerGUID then
        if subEvent == "SPELL_AURA_APPLIED" or subEvent == "SPELL_AURA_REFRESH" then
            if self.AbsorbSpells[arg9] and self.absorbDb[arg9] then
                local msg = (arg9 == 47753 and critAmout and critAmout * self.talentMultiplier[47753]) or tostring(self:CalculateAbsorbValue(arg9, self.absorbDb[arg9]))
                msg = msg..";"..arg9
                SendAddonMessage("WA_PAD", msg, "WHISPER", destName)
            end
        end
    end
end

aura_env.playerGUID = UnitGUID("player")
aura_env.playerClass = select(2, UnitClass("player"))
aura_env.playerName = UnitName("player")

aura_env.schoolIds = {127, 1, 126, 2, 4, 8, 16, 32, 64}
aura_env.schoolIdx = {}
for idx, id in ipairs(aura_env.schoolIds) do
    aura_env.schoolIdx[id] = idx
end
aura_env.absorbDbKeys = {
    ["school"] = 1,
    ["basePoints"] = 2,
    ["healingMultiplier"] = 3,
}
aura_env.absorbDb = {
    [47753] = {127, 2229, 0.8068}, -- [Priest] Divine Aegis
    [48066] = {127, 2229, 0.8068}, -- [Priest] Power Word: Shield (Rank 14)
    [43010] = {  4, 1950, 0.8053}, -- [Mage] Fire Ward (Rank 7)
    [43012] = { 16, 1950, 0.8053}, -- [Mage] Frost Ward (Rank 7)
    [43020] = {127, 1329, 0.8053}, -- [Mage] Mana Shield (Rank 9)
    [43039] = {127, 3299, 0.8053}, -- [Mage] Ice Barrier (Rank 8)
    [47891] = { 32, 3299,    0.3}, -- [Warlock] Shadow Ward (Rank 6)
    [47986] = {127, 8365,      0}, -- [Warlock] Sacrifice (Rank 9)
    [58597] = {127,  499,   0.75}, -- [Paladin] Sacred Shield
}
aura_env.MageFireWardSpells = {
    [543] = 30,
    [8457] = 30,
    [8458] = 30,
    [10223] = 30,
    [10225] = 30,
    [27128] = 30,
    [43010] = 30, 
}
aura_env.MageFrostWardSpells = {
    [6143] = 30,
    [8461] = 30,
    [8462] = 30,
    [10177] = 30,
    [28609] = 30,
    [32796] = 30,
    [43012] = 30,
}
aura_env.WarlockShadowWardSpells = {
    [6229] = 30,
    [11739] = 30,
    [11740] = 30,
    [28610] = 30,
    [47890] = 30,
    [47891] = 30,
}
aura_env.MageIceBarrierSpells = {
    [11426] = 60,
    [13031] = 60,
    [13032] = 60,
    [13033] = 60,
    [27134] = 60,
    [33405] = 60,
    [43038] = 60,
    [43039] = 60,
}
aura_env.WarlockSacrificeSpells = {
    [7812] = 30,
    [19438] = 30,
    [19440] = 30,
    [19441] = 30,
    [19442] = 30,
    [19443] = 30,
    [27273] = 30,
    [47985] = 30,
    [47986] = 30,
}
aura_env.AbsorbSpells = {
    [48707] = 5,
    [51052] = 10,
    [51271] = 20,
    [62606] = 10,
    [11426] = 60,
    [13031] = 60,
    [13032] = 60,
    [13033] = 60,
    [27134] = 60,
    [33405] = 60,
    [43038] = 60,
    [43039] = 60,
    [6143] = 30,
    [8461] = 30,
    [8462] = 30,
    [10177] = 30,
    [28609] = 30,
    [32796] = 30,
    [43012] = 30,
    [1463] = 60,
    [8494] = 60,
    [8495] = 60,
    [10191] = 60,
    [10192] = 60,
    [10193] = 60,
    [27131] = 60,
    [43019] = 60,
    [43020] = 60,
    [543] = 30 ,
    [8457] = 30,
    [8458] = 30,
    [10223] = 30,
    [10225] = 30,
    [27128] = 30,
    [43010] = 30,
    [58597] = 6,
    [17] = 30,
    [592] = 30,
    [600] = 30,
    [3747] = 30,
    [6065] = 30,
    [6066] = 30,
    [10898] = 30,
    [10899] = 30,
    [10900] = 30,
    [10901] = 30,
    [25217] = 30,
    [25218] = 30,
    [48065] = 30,
    [48066] = 30,
    [47509] = 12,
    [47511] = 12,
    [47515] = 12,
    [47753] = 12,
    [54704] = 12,
    [47788] = 10,
    [7812] = 30,
    [19438] = 30,
    [19440] = 30,
    [19441] = 30,
    [19442] = 30,
    [19443] = 30,
    [27273] = 30,
    [47985] = 30,
    [47986] = 30,
    [6229] = 30,
    [11739] = 30,
    [11740] = 30,
    [28610] = 30,
    [47890] = 30,
    [47891] = 30,
    [29674] = 86400,
    [29719] = 86400,
    [29701] = 86400,
    [28538] = 120,
    [28537] = 120,
    [28536] = 120,
    [28513] = 120,
    [28512] = 120,
    [28511] = 120,
    [7233] = 120,
    [7239] = 120,
    [7242] = 120,
    [7245] = 120,
    [7254] = 120,
    [53915] = 120,
    [53914] = 120,
    [53913] = 120,
    [53911] = 120,
    [53910] = 120,
    [17548] = 120,
    [17546] = 120,
    [17545] = 120,
    [17544] = 120,
    [17543] = 120,
    [17549] = 120,
    [28527] = 15,
    [29432] = 3600,
    [36481] = 4,
    [57350] = 6,
    [17252] = 30,
    [25750] = 15,
    [25747] = 15,
    [25746] = 15,
    [23991] = 15,
    [31000] = 300,
    [30997] = 300,
    [31002] = 300,
    [30999] = 300,
    [30994] = 300,
    [23506]= 20,
    [12561] = 60,
    [31771] = 20,
    [21956] = 10,
    [29506] = 20,
    [4057] = 60,
    [4077] = 60,
    [39228] = 20,
    [27779] = 30,
    [11657] = 20,
    [10368] = 15,
    [37515] = 15,
    [42137] = 86400,
    [26467] = 30,
    [26470] = 8,
    [27539] = 6,
    [28810] = 30,
    [54808] = 12,
    [55019] = 12,
    [64411] = 15,
    [64413] = 8,
    [40322] = 30,
    [65874] = 15,
    [67257] = 15,
    [67256] = 15,
    [67258] = 15,
    [65858] = 15,
    [67260] = 15,
    [67259] = 15,
    [67261] = 15,
    [65686] = 86400,
    [65684] = 86400,
}
